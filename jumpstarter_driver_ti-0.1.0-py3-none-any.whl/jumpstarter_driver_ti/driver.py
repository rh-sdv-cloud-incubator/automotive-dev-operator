from dataclasses import dataclass

from jumpstarter_driver_composite.driver import CompositeInterface

from jumpstarter.driver import Driver


@dataclass(kw_only=True)
class TiSetup(CompositeInterface, Driver):
    """TI Setup Driver"""
    log_level: str = "INFO"

    @classmethod
    def client(cls) -> str:
        return "jumpstarter_driver_ti.client.TiSetupClient"

    def __post_init__(self):
        if hasattr(super(), "__post_init__"):
            super().__post_init__()

        from jumpstarter_driver_composite.driver import Proxy

        self.children["tftp"] = Proxy(ref="tftp_driver")
        self.children["http"] = Proxy(ref="http_driver")
        self.children["serial"] = Proxy(ref="serial_driver")
        self.children["power"] = Proxy(ref="power_driver")

    def close(self):
        """Cleanup resources"""
        if hasattr(super(), "close"):
            super().close()
