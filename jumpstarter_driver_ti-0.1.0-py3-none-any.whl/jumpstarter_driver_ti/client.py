import logging
import os
import sys
import time
from pathlib import Path

import asyncclick as click
from jumpstarter_driver_composite.client import CompositeClient
from jumpstarter_driver_network.adapters import PexpectAdapter


class TiSetupClient(CompositeClient):
    def flash(self, kernel: str, dtb: str, os_image: str, os_image_checksum: str | None = None):
        self.logger.setLevel(logging.DEBUG)
        self.tftp.start()
        self.http.start()

        self.logger.info("Starting TFTP uploads...")

        # Upload kernel and dtb to TFTP
        for path_info in [("kernel", kernel), ("dtb", dtb)]:
            file_type, path = path_info
            filename = Path(path).name if not path.startswith(('http://', 'https://')) else path.split('/')[-1]
            self.logger.info(f"Uploading {filename} to TFTP server")

            # check if file is already uploaded
            if self.tftp.storage.exists(filename):
                self.logger.info(f"{filename} already uploaded")
                continue

            # Handle HTTP URLs with OpenDAL
            if path.startswith(('http://', 'https://')):
                self.logger.info(f"Downloading {file_type} from URL: {path}")
                from urllib.parse import urlparse

                from opendal import Operator

                parsed_url = urlparse(path)
                operator = Operator(
                    'http',
                    root='/',
                    endpoint=f"{parsed_url.scheme}://{parsed_url.netloc}"
                )
                remote_path = parsed_url.path
                if remote_path.startswith('/'):
                    remote_path = remote_path[1:]

                # Use OpenDAL to transfer from remote HTTP to local TFTP
                self.tftp.storage.write_from_path(filename, remote_path, operator)
            else:
                self.tftp.storage.write_from_path(filename, path)

            self.logger.info(f"Completed TFTP upload of {filename}")

        # Upload OS image to HTTP server
        self.logger.info("Starting HTTP upload...")
        os_image_name = Path(os_image).name if not os_image.startswith(('http://', 'https://')) else os_image.split('/')[-1]
        self.logger.info(f"Uploading {os_image_name} to HTTP server")

        # For OS image, also use OpenDAL with proper configuration
        if os_image.startswith(('http://', 'https://')):
            from urllib.parse import urlparse

            from opendal import Operator

            parsed_url = urlparse(os_image)
            operator = Operator(
                'http',
                root='/',
                endpoint=f"{parsed_url.scheme}://{parsed_url.netloc}"
            )
            remote_path = parsed_url.path
            if remote_path.startswith('/'):
                remote_path = remote_path[1:]

            # Use HTTP storage to write from remote URL
            self.http.storage.write_from_path(os_image_name, remote_path, operator)
        else:
            # Upload local file to our HTTP server
            self.http.storage.write_from_path(os_image_name, os_image)

        # Get the full URL to the uploaded image
        http_url = self.http.get_url()
        image_url = f"{http_url}/{os_image_name}"
        self.logger.info(f"OS image available at: {image_url}")

        try:
            self.power.cycle()
            with PexpectAdapter(client=self.children["serial"]) as console:
                console.logfile = sys.stdout.buffer
                for _ in range(50):
                    console.send('\x1b')
                    time.sleep(0.1)
                self.logger.info("Waiting for U-Boot prompt...")
                console.expect(["Boot Menu", "Hit any key to stop autoboot", "=>"], timeout=120)
                for _ in range(50):
                    console.send('\x1b')
                    time.sleep(0.1)

                self.logger.info("Configuring network...")
                console.sendline("dhcp")
                console.expect("=>")

                tftp_host = self.tftp.get_host()
                env_vars = {
                    "serverip": tftp_host,
                }

                for key, value in env_vars.items():
                    self.logger.info(f"Setting env {key}={value}")
                    console.sendline(f"setenv {key} '{value}'")
                    console.expect("=>")

                console.sendline(f"tftpboot 0x82000000 {Path(kernel).name if not kernel.startswith(('http://', 'https://')) else kernel.split('/')[-1]}")
                console.expect("=>")

                console.sendline(f"tftpboot 0x84000000 {Path(dtb).name if not dtb.startswith(('http://', 'https://')) else dtb.split('/')[-1]}")
                console.expect("=>")

                console.sendline("booti 0x82000000 - 0x84000000")

                # wait for login prompt
                console.expect("login:", timeout=300)
                console.sendline("root")
                console.expect("#")
                console.sendline("udhcpc")
                console.expect("#", timeout=90)

                console.sendline(
                    "dd if=/dev/zero of=/dev/mmcblk0 bs=512 count=34 &&"
                    "dd if=/dev/zero of=/dev/mmcblk1 bs=512 count=34"
                )
                console.expect("#", timeout=90)
                self.logger.info("detecting uSD device...")
                console.sendline("ls -lah /sys/class/block/ | grep 4fb0000")
                console.expect("#")
                mmc_output = console.before.decode()

                if "mmcblk0" in mmc_output:
                    mmc_device = "mmcblk0"
                elif "mmcblk1" in mmc_output:
                    mmc_device = "mmcblk1"
                else:
                    raise Exception("could not detect uSD device")

                self.logger.info(f"using uSD device: /dev/{mmc_device}")
                self.logger.info("Flashing OS image...")

                os_image_name = os_image.split('/')[-1] if os_image.startswith(('http://', 'https://')) else Path(os_image).name
                decompress_cmd = _get_decompression_command(os_image_name)

                flash_cmd = (
                    f'wget -O - "{image_url}" | '
                    f'{decompress_cmd} | '
                    f'dd of=/dev/{mmc_device} bs=64K iflag=fullblock'
                )
                console.sendline(flash_cmd)
                console.expect("#", timeout=1200)

                self.power.cycle()
                self.logger.info("Performing final boot...")
                console.expect("login:", timeout=300)
                console.sendline("root")
                console.expect("Password:")
                console.sendline("password")
                console.expect("#")

                return "Flash and boot completed successfully"

        except Exception as e:
            self.logger.error(f"Flash failed: {str(e)}")
            raise

    def cli(self):
        @click.group()
        def base():
            """TI Driver"""
            pass

        @base.command()
        @click.option('--kernel', required=True,
                        help='Kernel image file (local path or URL)')
        @click.option('--dtb', required=True,
                        help='Device Tree Binary file (local path or URL)')
        @click.option('--os-image', required=True,
                        help='Operating system image to flash (local path or URL)')
        @click.option('--os-image-checksum',
                        help='SHA256 checksum of OS image (direct value)')
        @click.option('--os-image-checksum-file',
                        help='File containing SHA256 checksum of OS image',
                        type=click.Path(exists=True, dir_okay=False))
        def flash(kernel, dtb, os_image, os_image_checksum, os_image_checksum_file):
            if os_image_checksum_file and os.path.exists(os_image_checksum_file):
                with open(os_image_checksum_file) as f:
                    os_image_checksum = f.read().strip().split()[0]
                    self.logger.info(f"Read checksum from file: {os_image_checksum}")

            try:
                result = self.flash(kernel, dtb, os_image, os_image_checksum)
                click.echo(result)
            except Exception as e:
                self.logger.error(f"Flash failed: {str(e)}")
                sys.exit(1)

        for name, child in self.children.items():
            if hasattr(child, "cli"):
                base.add_command(child.cli(), name)

        return base

def _get_decompression_command(filename: str) -> str:
    """
    Determine the appropriate decompression command based on file extension

    Args:
        filename (str): Name of the file to check

    Returns:
        str: Decompression command ('zcat', 'xzcat', or 'cat' for uncompressed)
    """
    filename = filename.lower()
    if filename.endswith(('.gz', '.gzip')):
        return 'zcat'
    elif filename.endswith('.xz'):
        return 'xzcat'
    return 'cat'
